# 𝐓𝐡𝐞 𝐆𝐚𝐦𝐢𝐧𝐠 𝐂𝐞𝐧𝐭𝐞𝐫 𝐕𝟐 (𝐔𝐏𝐃𝐀𝐓𝐄𝐃!)

A beta testing site.

## New Additions

Games
- SM64
- Retro Bowl
- Basket Bros
- Idle Breakout
- DS Player

Features
- Game sorting (beta)
- Totally W interface no 🧢 not trippin'

Patch Notes

- Removed Super Mario World
- Fixed Idle Breakout
- Added DS Player (Brought Back From the Dead)
- Supplyed 3 new DS ROMS (Pokemon Platinum, Pokemon Diamond, Super Mario 64 DS)
- Added ForeFront AI

## Info

Please star if you fork or find this useful.

## Contribution

If you want to contribute, fork this repository, make your changes, and commit a pull request towards this repo.

ඞඞඞ Amongi
