Once you download a ROM, put it into a designated folder (ex., On My iPad/ROMS/thisrom.nds) and when prompted to supply the ROM, enter the ROMS directory (or whatever you may have set it to), and choose your game. There you go, now get gaming!

Other ROM links:

- https://archive.org/download/pokemon-diamond-version-usa-rev-5/Pokemon%20-%20Diamond%20Version%20%28USA%29%20%28Rev%205%29.nds (Pokemon Diamond)
- https://archive.org/download/pokemon-platinum-version-usa-rev-1/Pok%C3%A9mon%20-%20Platinum%20Version%20%28USA%29%20%28Rev%201%29.nds (Pokemon Platinum)
